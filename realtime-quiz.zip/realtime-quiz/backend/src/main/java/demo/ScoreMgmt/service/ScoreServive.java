package demo.ScoreMgmt.service;


import demo.QuizMgmt.dto.AnswersRequest;

public interface ScoreServive {

  void updateScore(AnswersRequest answersRequest);

}
